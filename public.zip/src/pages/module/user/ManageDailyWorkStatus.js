import DataTable from 'datatables.net-react';
import DT from 'datatables.net-dt';
import $ from 'jquery';
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import 'daterangepicker/daterangepicker.css'; // Import daterangepicker CSS
import 'daterangepicker'; // Import daterangepicker JS
import moment from 'moment';
import 'select2/dist/css/select2.css';
import 'select2';
import CustomLoader from '../../../components/CustomLoader';
import { RefreshCcw, FilterIcon } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import QueryDetails from '../../managequery/QueryDetails';


const ManageDailyWorkStatus = () => {
    const [todayArr, setTodayArr] = useState([]);
    const [nextdayArr, setNextDayArr] = useState([]);
    const [todayStatusCounts, setTodayStatusCounts] = useState({});
    const [nextdayStatusCounts, setNextDayStatusCounts] = useState({});
    const [refId, setRefId] = useState('');
    const [dateFilter, setDateFilter] = useState('today');
    const [yestStatus, setYestStatus] = useState('');
    const [status, setStatus] = useState('');
    const [selectedUser, setSelectedUser] = useState('')
    const [loading, setLoading] = useState(false);

    DataTable.use(DT);



    // Fetch all data on initial render
    useEffect(() => {
        fetchFilteredQuotes();


    }, []);



    const fetchFilteredQuotes = async () => {
        setLoading(true);
        try {
            const response = await fetch('https://99crm.phdconsulting.in/zend/api/getalldailyworkstatus', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    date_filter: dateFilter,
                    user_id: selectedUser,
                    status: status,
                    yest_status: yestStatus,
                    team_id: sessionStorage.getItem('team_id'),
                    user_type: sessionStorage.getItem('user_type')
                }),
            });

            const data = await response.json(); // Parse the response as JSON

            if (data.status) {

                setTodayArr(data?.todayArr)
                setNextDayArr(data?.nextDayArr)

                setTodayStatusCounts(data?.yesterdayStatusCounts)
                setNextDayStatusCounts(data?.todayStatusCounts)
            }
        } catch (error) {
            console.error('Error fetching filtered quotes:', error);
        } finally {
            setLoading(false);
        }
    };




    const columns = [


        {
            title: 'Name',
            data: 'name',
            orderable: false,
            render: (data, type, row) => {
                let profilesHtml = '';

                if (row.profiles && row.profiles.length > 0) {
                    profilesHtml = row.profiles
                        .map((profile) => {
                            const parts = profile.profile_name.split('-');
                            const name = parts[1] ? parts[1].trim() : profile.profile_name;
                            const color = profile.profile_status == 1 ? '#258ac5' : 'red';
                            return `<span style="color:${color}; font-size: 12px;">${name}</span>`;
                        })
                        .join(' | ');
                }

                return `
            <div style="text-align: left;">
                <div style="font-weight: bold;">${data}</div>
                <div>${profilesHtml}</div>
            </div>
        `;
            }
        }
        ,
        {
            title: 'Work Status',
            data: 'selected_work_status',
            orderable: false,
            render: (data) => {
                let label = '';
                if (data == 1) {
                    label = 'Max Fresh';
                } else if (data == 2) {
                    label = 'Few Fresh';
                } else if (data == 3) {
                    label = 'No Leads';
                }
                return `<div style="text-align: left;">${label}</div>`;
            },
        },
        {
            title: 'Submitted Date',
            data: 'selected_at',
            orderable: false,
            render: (data) => {
                if (!data) return '';

                const date = new Date(data);
                return date.toLocaleString('en-GB', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true,
                });
            },
        },
        {
            title: 'today Assigned Leads',
            data: 'lead_count',
            orderable: false,
            render: (data) => `<div style="text-align: left;">${data}</div>`,
        },
        {
            title: "Last 3 day's Assigned Leads",
            data: 'last_3day_lead',
            orderable: false,
            render: (data) => `<div style="text-align: left;">${data}</div>`,
        },




    ];
    const NextDayColumns = [


        {
            title: 'Name ',
            data: 'name',
            orderable: false,
            render: (data) => `<div style="text-align: left;">${data}</div>`,
        },
        {
            title: 'Work Status',
            data: 'selected_work_status',
            orderable: false,
            render: (data) => {
                let label = '';
                if (data == 1) {
                    label = 'Need Max Fresh Enquiries';
                } else if (data == 2) {
                    label = 'Need Few Fresh Enquiries';
                } else if (data == 3) {
                    label = 'No Leads Required';
                }
                return `<div style="text-align: left;">${label}</div>`;
            },
        },
        {
            title: 'Submitted Date',
            data: 'selected_at',
            orderable: false,
            render: (data) => {
                if (!data) return '';

                const date = new Date(data);
                return date.toLocaleString('en-GB', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true,
                });
            },
        },
    ];

    const resetFilters = () => {
        setStatus('');
        setYestStatus('');
        fetchFilteredQuotes();  // Fetch unfiltered data
    };

    useEffect(() => {
        fetchFilteredQuotes();
    }, [status, yestStatus])


    return (
        <div className="container bg-gray-100 w-full add">
            <div className='flex w-full justify-end my-1 py-3'>
                <button
                    className='bg-orange-400 text-white px-1 py-0.5 rounded flex items-center f-11'
                    onClick={resetFilters}
                >
                    Reload <RefreshCcw size={15} className='ml-2' />
                </button>
            </div>

            {loading ? (
                <CustomLoader />
            ) : (
                <div className="bg-white py-4 px-2 border-t-2 border-blue-400 rounded grid grid-cols-2 gap-4">
                    {/* Today's Work Status */}
                    <div className="bg-yellow-50 p-2 rounded shadow-sm flex flex-col">
                        <h1 className="text-lg font-bold mb-3">Today's Work Status</h1>

                        {/* Buttons Row */}
                        <div className="flex flex-wrap gap-2 mb-3">
                            {[
                                { value: "", label: "All" },
                                { value: "1", label: "Max Fresh" },
                                { value: "2", label: "Few Fresh" },
                                { value: "3", label: "No Leads" },
                            ].map((option) => {
                                const count =
                                    option.value === ""
                                        ? Object.values(todayStatusCounts || {}).reduce((a, b) => a + b, 0)
                                        : todayStatusCounts?.[option.value] ?? 0;

                                return (
                                    <button
                                        key={option.value}
                                        className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition 
              ${yestStatus === option.value
                                                ? "bg-blue-600 text-white border-blue-600"
                                                : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
                                            }`}
                                        onClick={() => setYestStatus(option.value)}
                                    >
                                        {option.label} <span className="font-semibold bg-white rounded-full px-1 f-11 text-black">{count}</span>
                                    </button>
                                );
                            })}
                        </div>

                        {/* DataTable */}
                        <div className="bg-white rounded-lg shadow-sm flex-1 overflow-hidden">
                            <DataTable
                                data={todayArr}
                                columns={columns}
                                options={{
                                    pageLength: 50,
                                    createdRow: (row, data) => {

                                    },
                                }}
                            />
                        </div>
                    </div>

                    {/* Next Day's Work Status */}
                    <div className="bg-blue-50 p-2 rounded shadow-sm flex flex-col">
                        <h1 className="text-lg font-bold mb-3">Next Day's Work Status</h1>

                        {/* Buttons Row */}
                        <div className="flex flex-wrap gap-2 mb-3">
                            {[
                                { value: "", label: "All" },
                                { value: "1", label: "Max Fresh" },
                                { value: "2", label: "Few Fresh" },
                                { value: "3", label: "No Leads" },
                            ].map((option) => {
                                const count =
                                    option.value === ""
                                        ? Object.entries(nextdayStatusCounts || {})
                                            .filter(([key]) => key !== "")
                                            .reduce((a, [, b]) => a + b, 0)
                                        : nextdayStatusCounts?.[option.value] ?? 0;

                                return (
                                    <button
                                        key={option.value}
                                        className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition 
              ${status === option.value
                                                ? "bg-blue-600 text-white border-blue-600"
                                                : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
                                            }`}
                                        onClick={() => setStatus(option.value)}
                                    >
                                        {option.label} <span className="font-semibold bg-white rounded-full px-1 f-11 text-black">{count}</span>
                                    </button>
                                );
                            })}
                        </div>

                        {/* DataTable */}
                        <div className="bg-white rounded-lg shadow-sm flex-1 overflow-hidden">
                            <DataTable
                                data={nextdayArr}
                                columns={NextDayColumns}
                                options={{
                                    pageLength: 50,
                                    createdRow: (row, data) => {

                                    },
                                }}
                            />
                        </div>
                    </div>
                </div>

            )}

            <AnimatePresence>

            </AnimatePresence>
        </div>
    );
};

export default ManageDailyWorkStatus;
